#include "steep.h"

void Steep_Init(void)
{
	
	P0M1 = 0x10;
	P0M0 = 0x0f;
	ap = 1;
	bp = 1;
	cp = 1;
	dp = 1;

}

void ff_setp()
{
	ap = 1;
	bp = 0;
	cp = 0;
	dp = 1;
	Delay_ms(10);
	bp = 1;
	dp = 0;
	Delay_ms(10);
	cp = 1;
	ap = 0;
	Delay_ms(10);
	dp = 1;
	bp = 0;
	Delay_ms(10);	
}

void bw_setp()
{
	ap = 1;
	bp = 1;
	cp = 0;
	dp = 0;
	Delay_ms(10);
	bp = 0;
	dp = 1;
	Delay_ms(10);
	ap = 0;
	cp = 1;
	Delay_ms(10);
	dp = 0;
	bp = 1;
	Delay_ms(10);		
}