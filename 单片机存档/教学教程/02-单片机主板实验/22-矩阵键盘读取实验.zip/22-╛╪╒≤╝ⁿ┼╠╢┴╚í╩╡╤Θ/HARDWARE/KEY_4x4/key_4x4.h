#ifndef __KEY_4x4_H_
#define __KEY_4x4_H_	 


#include <system.h>

uint8_t Get_KeyValue(void);
					    
#endif
